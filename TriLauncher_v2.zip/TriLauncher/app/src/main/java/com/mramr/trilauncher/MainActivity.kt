package com.mramr.trilauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    class App(val label: String, val comp: ComponentName, val info: ResolveInfo)

    private val wps = listOf(
        "blackhole" to "Black Hole (pure OLED)",
        "ocean" to "Deep Ocean",
        "aurora" to "Soft Aurora",
        "dusk" to "Quiet Dusk"
    )

    private var all = listOf<App>()
    private var shown = listOf<App>()
    private val icons = HashMap<ComponentName, Drawable>()
    private val prefs by lazy { getSharedPreferences("tri", MODE_PRIVATE) }
    private lateinit var bg: ImageView
    private lateinit var scrim: View
    private lateinit var favBox: LinearLayout
    private lateinit var dockBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private lateinit var gd: GestureDetector
    private var drawerOpen = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun icon(a: App): Drawable = icons.getOrPut(a.comp) { a.info.loadIcon(packageManager) }

    private fun glass(r: Int, alpha: Int) = GradientDrawable().apply {
        setColor(Color.argb(alpha, 255, 255, 255))
        cornerRadius = dp(r).toFloat()
        setStroke(dp(1), Color.argb(46, 255, 255, 255))
    }

    private fun wpRes(k: String): Int = when (k) {
        "ocean" -> R.drawable.wp_ocean
        "aurora" -> R.drawable.wp_aurora
        "dusk" -> R.drawable.wp_dusk
        else -> R.drawable.wp_blackhole
    }

    private fun soft(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    x.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    private fun tile(a: App, size: Int, pad: Int): ImageView {
        val iv = ImageView(this)
        iv.setImageDrawable(icon(a))
        iv.setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        val r = if (prefs.getInt("shape", 1) == 0) size / 2 else (size * 0.3f).toInt()
        iv.background = glass(r, 40)
        return iv
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        bg = ImageView(this)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        scrim = View(this)
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        val home = LinearLayout(this)
        home.orientation = LinearLayout.VERTICAL
        home.setPadding(dp(24), dp(60), dp(24), dp(28))
        home.setOnLongClickListener { showMenu(); true }
        home.addView(TextClock(this).apply {
            format12Hour = "h:mm"; format24Hour = "HH:mm"
            textSize = 68f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        })
        home.addView(TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"; format24Hour = "EEEE, d MMMM"
            textSize = 15f
            setTextColor(0xCCFFFFFF.toInt())
        })
        home.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        favBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(26, 26)
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        home.addView(favBox)
        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass(34, 30)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        home.addView(dockBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        val pill = TextView(this).apply {
            text = "Search apps"
            textSize = 15f
            setTextColor(0xAAFFFFFF.toInt())
            setPadding(dp(22), dp(14), dp(22), dp(14))
            background = glass(28, 30)
            setOnClickListener { openDrawer() }
        }
        soft(pill)
        home.addView(pill, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        home.addView(TextView(this).apply {
            text = "By Mr Amr"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(0x66FFFFFF)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (Build.VERSION.SDK_INT >= 31) Color.argb(150, 0, 0, 0) else Color.argb(238, 0, 0, 0))
            setPadding(dp(18), dp(52), dp(18), dp(12))
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 16f
            isSingleLine = true
            background = glass(28, 30)
            setPadding(dp(22), dp(12), dp(22), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val q = s?.toString()?.trim().orEmpty()
                    shown = if (q.isEmpty()) all else all.filter { it.label.contains(q, true) }
                    (grid.adapter as BaseAdapter).notifyDataSetChanged()
                }
            })
        }
        drawer.addView(search, LinearLayout.LayoutParams(-1, -2))
        grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(18)
            setSelector(android.R.color.transparent)
            adapter = Ad()
            setOnItemClickListener { _, _, p, _ -> launch(shown[p]) }
            setOnItemLongClickListener { _, _, p, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + shown[p].comp.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                true
            }
        }
        drawer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(18) })
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!drawerOpen && vy < -1200) openDrawer()
                else if (drawerOpen && vy > 1500 && !grid.canScrollVertically(-1)) closeDrawer()
                return false
            }
        })
        applyLook()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawerOpen) closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
    }

    private fun applyLook() {
        val k = prefs.getString("wp", "blackhole") ?: "blackhole"
        val f = File(filesDir, "custom.jpg")
        if (k == "custom" && f.exists()) bg.setImageBitmap(BitmapFactory.decodeFile(f.path))
        else bg.setImageResource(wpRes(k))
        val a = intArrayOf(20, 90, 150)[prefs.getInt("dim", 1).coerceIn(0, 2)]
        scrim.setBackgroundColor(Color.argb(a, 0, 0, 0))
        if (all.isNotEmpty()) buildHome()
    }

    private fun dlg() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun showMenu() {
        dlg().setTitle("TriLauncher")
            .setItems(arrayOf("Wallpaper", "Photo dimming", "Icon style")) { _, w ->
                when (w) {
                    0 -> pickWallpaper()
                    1 -> pickDim()
                    2 -> pickShape()
                }
            }.show()
    }

    private fun pickWallpaper() {
        val names = wps.map { it.second } + "My photo from gallery"
        dlg().setTitle("Wallpaper").setItems(names.toTypedArray()) { _, i ->
            if (i < wps.size) {
                prefs.edit().putString("wp", wps[i].first).apply()
                applyLook()
            } else {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 11)
            }
        }.show()
    }

    private fun pickDim() {
        dlg().setTitle("Photo dimming").setItems(arrayOf("Light", "Medium", "Strong")) { _, i ->
            prefs.edit().putInt("dim", i).apply()
            applyLook()
        }.show()
    }

    private fun pickShape() {
        dlg().setTitle("Icon style").setItems(arrayOf("Round", "Soft square")) { _, i ->
            prefs.edit().putInt("shape", i).apply()
            applyLook()
        }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 11 && resultCode == RESULT_OK && uri != null) savePhoto(uri)
    }

    private fun savePhoto(uri: Uri) {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 1600 || o.outHeight / s > 2400) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                Toast.makeText(this, "Could not open that photo", Toast.LENGTH_SHORT).show()
                return
            }
            File(filesDir, "custom.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            prefs.edit().putString("wp", "custom").apply()
            applyLook()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not use that photo", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openDrawer() {
        drawerOpen = true
        if (Build.VERSION.SDK_INT >= 31) {
            bg.setRenderEffect(RenderEffect.createBlurEffect(32f, 32f, Shader.TileMode.CLAMP))
        }
        drawer.visibility = View.VISIBLE
        drawer.alpha = 0f
        drawer.translationY = dp(60).toFloat()
        drawer.animate().alpha(1f).translationY(0f).setDuration(240).start()
    }

    private fun closeDrawer() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        drawerOpen = false
        search.setText("")
        if (Build.VERSION.SDK_INT >= 31) bg.setRenderEffect(null)
        drawer.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(200)
            .withEndAction { drawer.visibility = View.GONE }.start()
    }

    private fun launch(a: App) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(a.comp)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { startActivity(i) } catch (e: Exception) { }
        if (drawerOpen) closeDrawer()
    }

    private fun load() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = packageManager.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                App(it.loadLabel(packageManager).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name), it)
            }
            .sortedBy { it.label.lowercase() }
        shown = all
        (grid.adapter as BaseAdapter).notifyDataSetChanged()
        buildHome()
    }

    private fun pick(groups: List<List<String>>, used: MutableSet<ComponentName>): List<App> {
        val out = ArrayList<App>()
        for (g in groups) {
            val m = all.firstOrNull { a ->
                a.comp !in used && g.any { t ->
                    a.comp.packageName.contains(t, true) || a.label.contains(t, true)
                }
            }
            if (m != null) { out.add(m); used.add(m.comp) }
        }
        return out
    }

    private fun buildHome() {
        val used = HashSet<ComponentName>()
        val favs = pick(listOf(listOf("whatsapp"), listOf("chrome"), listOf("instagram"),
            listOf("youtube"), listOf("settings")), used)
        val dock = pick(listOf(listOf("dialer", "phone", "contacts"), listOf("messag", "mms"),
            listOf("camera"), listOf("gallery", "photos")), used)
        favBox.removeAllViews()
        dockBox.removeAllViews()
        favBox.visibility = if (favs.isEmpty()) View.GONE else View.VISIBLE
        for (a in favs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
                setOnClickListener { launch(a) }
            }
            soft(row)
            row.addView(tile(a, 40, 7), LinearLayout.LayoutParams(dp(40), dp(40)))
            row.addView(TextView(this).apply {
                text = a.label
                textSize = 18f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(14) })
            favBox.addView(row)
        }
        for (a in dock) {
            val iv = ImageView(this).apply {
                setImageDrawable(icon(a))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { launch(a) }
            }
            soft(iv)
            dockBox.addView(iv, LinearLayout.LayoutParams(0, dp(56), 1f))
        }
    }

    inner class Ad : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val a = shown[position]
            val l = LinearLayout(this@MainActivity)
            l.orientation = LinearLayout.VERTICAL
            l.gravity = Gravity.CENTER_HORIZONTAL
            l.addView(tile(a, 56, 10), LinearLayout.LayoutParams(dp(56), dp(56)))
            l.addView(TextView(this@MainActivity).apply {
                text = a.label
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTextColor(0xCCFFFFFF.toInt())
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
            return l
        }
    }
}
