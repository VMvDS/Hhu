TriLauncher v2 (By Mr Amr)
Build: upload this folder to a GitHub repository, open Actions > Build APK > download TriLauncher-APK.
Customize: long-press an empty spot on the home screen (wallpaper, photo dimming, icon style).
